@echo off
if %PROCESSOR_ARCHITECTURE%==AMD64 start .\x64\Setup.exe
if %PROCESSOR_ARCHITECTURE%==x86 start .\x86\Setup.exe
